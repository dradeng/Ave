module.exports = {
  mongoURI: 'mongodb://dradengaffney:Sawyer11@ds115283.mlab.com:15283/devconnector',
  GoogleMapsApi: 'AIzaSyBl9N_4Qo5m-IElGXKpz62Ah42YaUSSU2g',
  secretOrKey: 'secret',
  IAmUserKey: 'AKIAJWKEGIO25SQYHHGA',
  IAmUserSecret: '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',
  BucketName: 'aveneu'
};
